Compile code: javac *.java 

Running code: java PostOfficeSimulator


